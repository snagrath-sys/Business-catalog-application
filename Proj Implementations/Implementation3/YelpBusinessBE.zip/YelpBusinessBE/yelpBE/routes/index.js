const cors = require('cors');
var express = require('express');
var router = express.Router();
const axios = require('axios');
let lat, long;
var latLong;
var yelp_list_endpoint = 'https://api.yelp.com/v3/businesses/search'
var yelp_detail_endpoint = 'https://api.yelp.com/v3/businesses/'
var yelp_autoC_endpoint = 'https://api.yelp.com/v3/autocomplete?text=';
var yelp_api_token='zZwarD1JwiWMNm1DjJi0PoKBBdoqHdbQV6vJrGEM7Z0a7aHlSLp73vCMRZ3EGoqsPKKSZpav0bWbIGctonjl2wyDlPhh2_dWQ37KmUT6SWECEfvCUVdAuqJ4BjlHY3Yx';

router.use(cors());

function mile_to_metre(miles){
  return (miles * 1609.34);
}    

function metre_to_mile(metre){
  return (metre / 1609.34);
}
    

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Expresses' });
});

router.get('/search', function(req, res, next) {
  res.render('index', { title: 'Expresses' });
});

function category_mapping(cat){
  var categoryMap = new Map();
  categoryMap.set('Default', 'all');
  categoryMap.set('Arts & Entertainment', 'arts');
  categoryMap.set('Health & Medical','health');
  categoryMap.set('Hotels & Travel', 'hotelstravel');
  categoryMap.set('Food', 'food');
  categoryMap.set('Professional Services', 'professional');
  if(categoryMap.has(cat)){
    return (categoryMap.get(cat));
  }
  return null;
}

async function fetchLocationLatLong()
{   
    uri = "https://ipinfo.io/json?token=3f8c2f7011cf20";
    await axios.get(uri).then(res => {
      latLongArr = res.data.loc.split(',');
      lat = parseFloat(latLongArr[0]);
      long = parseFloat(latLongArr[1]);
      ans = {
        lat: lat,
        long:long
      };
      return ans;
    }).catch((err)=> console.log("Please Enter valid address"+ err))
    return ans;
}

async function fetchLocationGeo(uri)
{  
    var ans = {};
    await axios.get(uri).then(res => {
      lat = res.data["results"][0]["geometry"]["location"]["lat"];
      long = res.data["results"][0]["geometry"]["location"]["lng"];
      ans = {
        lat: lat,
        long: long
      };
      return ans;
    }).catch((err)=> console.log("Please Enter valid address"+ err))
    return ans;
}
//End point to get yelp business details
router.get('/yelpBusinessDetails', async function(req, response, next){
    //Extract all form entries.
    var keyword  = req["query"].term;
    var location = req["query"].location;
    var category = req["query"].categories;
    var distance, lat, long;
    var autoLocationEnabled = req["query"].autolocation;
    console.log("SN req receiever on server: "+ req);
    console.log("SN parameter extracted- keyword: "+ keyword + "location: "+ location+ "categor: "+ category+ "autoLocEn"+ autoLocationEnabled);

    //Resolve Location into latitude- longitude
    if(autoLocationEnabled == "true"){
      console.log("SN autoLocEnabled, resolving lat long ipinfo");
      latLong = await fetchLocationLatLong();
      console.log("SN Resolved1 lat: "+ latLong.lat + " long: "+ latLong.long);
    }
    else if(location != ""){
      console.log("SN autoL disabled, resolve adress using geoencoding ");
      loc = await encodeURIComponent(location);
      latLong =  await fetchLocationGeo("https://maps.googleapis.com/maps/api/geocode/json?address="+loc+'&'+"key="+"AIzaSyC5vDdgBj5GOPalNIhV6VgDUWbhPVf0Vu8");
      console.log("SN Resolved2 lat: "+ latLong.lat + " long: "+ latLong.long);
    }
    else{
      console.log("Catch rare case of neither autoL enabled nor location string given");
      return;
    }
 
    
    //Convert distance into metres
    try{
      distance = req["query"].radius;
      dist = mile_to_metre(distance);      
    }
    catch{
      //distance not present
      console.log("No distance provided");
    }
    
    cat = category_mapping(category);
    var query_string = yelp_list_endpoint+'?term='+keyword+'&latitude='+String(latLong.lat)+'&longitude='+String(latLong.long);
    if(dist){
      query_string+='&radius='+String(Math.round(dist));
    }

    if(cat){
      query_string+='&categories=' + cat;
    }

    query_string+='&limit=10';
    console.log("SN yelp search business query: "+ query_string);
    await axios.get(query_string ,
       { headers: {"Authorization" : `Bearer ${yelp_api_token}`
            } 
    })
.then(data => {
  let temp = data.data;
  // return response.json(temp);
  var businessListObj={}
  businessListObj = buildBusinessListObj(temp.businesses);
  console.log("garbage returned");
  console.log(businessListObj);
  return response.json(businessListObj);
})
.catch((error) => {
  console.log(error)
});
  return response;
    
});
router.get('/yelpBusinessCard', async function(req, response, next){
  console.log("Request ready for value extraction: "+ req["query"].key);

  query_string = yelp_detail_endpoint + req["query"].key;

  console.log("Final query string to be sent to Yelp server: "+ query_string);

  await axios.get(query_string,
    { headers: {"Authorization" : `Bearer ${yelp_api_token}`}
    }
    )
    .then(data => {
      let tmp = data.data;
      console.log("Response data");
      console.log(tmp);
      return response.json(tmp);
    }
    )
    .catch((error) => {
      console.log("Error thrown by Yelp server on business details query", error);
    });
    return response;
});

router.get('/yelpAutoComplete', async function(req, response, next){
  console.log("Request ready for value extraction: "+ req["query"].key);

  query_string = yelp_autoC_endpoint + req["query"].key;

  console.log("Final query string to be sent to Yelp server: "+ query_string);

  await axios.get(query_string,
    { headers: {"Authorization" : `Bearer ${yelp_api_token}`}
    }
    )
    .then(data => {
      let tmp = data.data;
      console.log("Response data");
      console.log(tmp);
      return response.json(tmp);
    }
    )
    .catch((error) => {
      console.log("Error thrown by Yelp server on autoComplete query", error);
    });
    return response;
});


router.get('/yelpReviewCard', async function(req, response, next){
  console.log("Request ready for review extraction: "+ req["query"].key);

  query_string = yelp_detail_endpoint + req["query"].key+'/reviews';

  console.log("Final query string to be sent to Yelp server for reviews: "+ query_string);

  await axios.get(query_string,
    { headers: {"Authorization" : `Bearer ${yelp_api_token}`}
    }
    )
    .then(data => {
      let tmp = data.data;
      console.log("Response review data");
      console.log(tmp);
      return response.json(tmp);
    }
    )
    .catch((error) => {
      console.log("Error thrown by Yelp server on business review query", error);
    });
    return response;
});

function buildBusinessListObj(temp){
  businessListing = {};
  
  
  for(var i=0;i<temp.length;i++){
    busuinessList ={};
    busuinessList.id = (temp[i].id!= undefined)? temp[i]['id']:null;
    busuinessList.image = (temp[i].image_url!= undefined)? temp[i]['image_url']:null;
    busuinessList.business_name = (temp[i].name != undefined)? temp[i]['name']:null;
    busuinessList.rating = (temp[i].rating!= undefined)? temp[i]['rating']:null; 
    busuinessList.distance = (temp[i].distance!= undefined)? metre_to_mile(temp[i]['distance']):null;
    businessListing[String(i)]=busuinessList;
  }
  
  return businessListing;
}
module.exports = router;
