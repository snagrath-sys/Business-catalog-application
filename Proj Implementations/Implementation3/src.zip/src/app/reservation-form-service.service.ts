import { Injectable } from '@angular/core';
import {Subject} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ReservationFormServiceService {
  reservationInfoEmitter:Subject<Object> = new Subject<Object>();
  newReserveEmitter:Subject<Object> = new Subject<Object>();
  constructor() { }


  newReservationUpdate(dataPack:any){
    console.log("Relay fnc"+dataPack);
    this.newReserveEmitter.next(dataPack);
  }
  makeReservation(businessName:any, businessID:any){
    var reserveInfo={
      bName:businessName, 
      bID:businessID};
    this.reservationInfoEmitter.next(reserveInfo);

  }
}
