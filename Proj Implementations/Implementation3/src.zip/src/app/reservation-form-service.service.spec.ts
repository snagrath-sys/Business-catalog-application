import { TestBed } from '@angular/core/testing';

import { ReservationFormServiceService } from './reservation-form-service.service';

describe('ReservationFormServiceService', () => {
  let service: ReservationFormServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReservationFormServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
