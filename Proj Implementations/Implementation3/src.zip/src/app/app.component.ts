import { Component } from '@angular/core';
import { FormBusinessTableServiceService } from './search-view/form-business-table-service.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'yelpBusinessApp';
  constructor(private __formBusinessTableServie: FormBusinessTableServiceService) {} 

clearSearchView(){
    this.__formBusinessTableServie.clearSearchViewBeforeBooking();

  }
  
}
