import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SearchViewComponent } from './search-view/search-view.component';
import { BookingViewComponent } from './booking-view/booking-view.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [
  { path: 'search', component: SearchViewComponent},
  {path:'', redirectTo:'/search', pathMatch: 'full'},
  {path: 'bookings', component:BookingViewComponent},
  {path:'**', component:PageNotFoundComponent} 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [SearchViewComponent, BookingViewComponent, PageNotFoundComponent]