import { TestBed } from '@angular/core/testing';

import { DetailsFormBookingsViewServiceService } from './details-form-bookings-view-service.service';

describe('DetailsFormBookingsViewServiceService', () => {
  let service: DetailsFormBookingsViewServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DetailsFormBookingsViewServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
