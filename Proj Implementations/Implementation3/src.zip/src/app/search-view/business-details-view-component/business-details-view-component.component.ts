import { Component, OnInit } from '@angular/core';
import { BusinessTableDetailsViewServiceService } from '../business-table-details-view-service.service';
import { FormBusinessTableServiceService } from '../form-business-table-service.service';
import {ReservationFormServiceService} from '../../reservation-form-service.service';

@Component({
  selector: 'app-business-details-view-component',
  templateUrl: './business-details-view-component.component.html',
  styleUrls: ['./business-details-view-component.component.css']
})
export class BusinessDetailsViewComponentComponent implements OnInit {
  makeReservation=true;
  BusinessDetailsDisplay=false;
  businessName:any="";
  businessID:any="";
  imageUrl:any;
  imageCorousel1:any='../../../assets/yelpImg.png';
  imageCorousel2:any='../../../assets/yelpImg.png';
  imageCorousel3:any='../../../assets/yelpImg.png';
  businessDetailsViewData:any;
  ifReview1:any = false;
  ifReview2:any=false;
  ifReview3:any=false;
  NoReviews:any=false;
  name1:any; name2:any;name3:any;ratingVal1:any;ratingVal2:any;ratingVal3:any;review1:any;
  review2:any;review3:any;reviewDate1:any;reviewDate2:any;reviewDate3:any;
  tweetUrl:any; 
  latitude:any=34.025354;
  longitude:any=-118.285446;
  displayMap:any=false;
  mapOptions: google.maps.MapOptions = {
   center: { lat: 38.9987208, lng: -77.2538699 },
   zoom : 14
}
marker = {
   position: { lat: 38.9987208, lng: -77.2538699 },
}
  twitterurl:any="";
  fburl:any="";
  columns=['address', 'category', 'phone_number', 'price', 'status', 'businessLink'];
  constructor(private __businessTableDetailsViewService: BusinessTableDetailsViewServiceService, private __formBusinessTableService:FormBusinessTableServiceService, private __reservationFormService: ReservationFormServiceService) { }
  
  
  reservationFormDisplay(){
    this.__reservationFormService.makeReservation(this.businessName, this.businessID);
    this.businessCardPopulate(this.businessDetailsViewData);
  }

  cancelReservation(){
    window.localStorage.removeItem(this.businessName);
    this.makeReservation = true;
    this.businessCardPopulate(this.businessDetailsViewData);
    window.alert("Reservation Cancelled!");
  }

  gotoBusinessTableView(){
      this.BusinessDetailsDisplay=false;
      this.__businessTableDetailsViewService.displayBusinessTableOnly();
}
  prepareImageCarousel(imgArr:any){
    if(!imgArr){
      return;
    }

    if(imgArr){
        var colouselVisibilityControl = document.getElementById("businessImages") as HTMLDivElement | null;
        colouselVisibilityControl!.style.visibility = "visible";
        this.imageCorousel1 = imgArr[0];
    }
    if(imgArr.length>1){
      this.imageCorousel2=imgArr[1];
    }
    if(imgArr.length>2){
      this.imageCorousel3= imgArr[2];
    }
  }
  renderMap(businessData:any){
    this.latitude = businessData["coordinates"]["latitude"];
    this.longitude = businessData["coordinates"]["longitude"];
    console.log("Lat: "+ this.latitude+ " long: "+ this.longitude);

    this.mapOptions= {
   center: { lat: this.latitude, lng: this.longitude },
   zoom : 14
}
   this.marker = {
   position: { lat: this.latitude, lng: this.longitude },
}
   this.displayMap=true;

  }

  businessReviewPopulate(businessReviewData:any){
    console.log("Review Data");
    console.log(businessReviewData);
    if(!businessReviewData || !businessReviewData["reviews"]){
      this.NoReviews=true;
      return;
    }
    if(businessReviewData && businessReviewData["reviews"].length>0){
      if(businessReviewData["reviews"][0] && businessReviewData["reviews"][0]["user"] && businessReviewData["reviews"][0]["user"]["name"]){
        this.name1= businessReviewData["reviews"][0]["user"]["name"];
      }
      else{
        this.name1="Mr. X";
      }
      if(businessReviewData["reviews"][0] && businessReviewData["reviews"][0]["rating"]){
        this.ratingVal1= businessReviewData["reviews"][0]["rating"];
      }
      else{
        this.ratingVal1=0;
      }
      if(businessReviewData["reviews"][0] && businessReviewData["reviews"][0]["text"]){
        this.review1= businessReviewData["reviews"][0]["text"];
      }
      else{
        this.review1="";
      }

      if(businessReviewData["reviews"][0] && businessReviewData["reviews"][0]["time_created"]){
        this.reviewDate1= businessReviewData["reviews"][0]["time_created"].split(/(\s+)/)[0];
      }
      else{
        this.reviewDate1="";
      }
    this.ifReview1=true;
    }

    if(businessReviewData && businessReviewData["reviews"].length>1){
      if(businessReviewData["reviews"][1] && businessReviewData["reviews"][1]["user"] && businessReviewData["reviews"][1]["user"]["name"]){
        this.name2= businessReviewData["reviews"][1]["user"]["name"];
      }
      else{
        this.name2="Mr. X";
      }
      if(businessReviewData["reviews"][1] && businessReviewData["reviews"][1]["rating"]){
        this.ratingVal2= businessReviewData["reviews"][1]["rating"];
      }
      else{
        this.ratingVal2=0;
      }
      if(businessReviewData["reviews"][1] && businessReviewData["reviews"][1]["text"]){
        this.review2= businessReviewData["reviews"][1]["text"];
      }
      else{
        this.review2="";
      }

      if(businessReviewData["reviews"][1] && businessReviewData["reviews"][1]["time_created"]){
        this.reviewDate2= businessReviewData["reviews"][1]["time_created"].split(/(\s+)/)[0];
      }
      else{
        this.reviewDate2="";
      }
    this.ifReview2=true;
    }

    if(businessReviewData && businessReviewData["reviews"].length>2){
      if(businessReviewData["reviews"][2] && businessReviewData["reviews"][2]["user"] && businessReviewData["reviews"][2]["user"]["name"]){
        this.name3= businessReviewData["reviews"][2]["user"]["name"];
      }
      else{
        this.name3="Mr. X";
      }
      if(businessReviewData["reviews"][2] && businessReviewData["reviews"][2]["rating"]){
        this.ratingVal3= businessReviewData["reviews"][2]["rating"];
      }
      else{
        this.ratingVal3=0;
      }
      if(businessReviewData["reviews"][2] && businessReviewData["reviews"][2]["text"]){
        this.review3= businessReviewData["reviews"][2]["text"];
      }
      else{
        this.review3="";
      }

      if(businessReviewData["reviews"][2] && businessReviewData["reviews"][2]["time_created"]){
        this.reviewDate3= businessReviewData["reviews"][2]["time_created"].split(/(\s+)/)[0];
      }
      else{
        this.reviewDate3="";
      }
    this.ifReview3=true;
    }


  }
  businessCardPopulate(businessData:any){
    this. businessDetailsViewData=businessData;
   if(window.localStorage.getItem(businessData['name'])){
    this.makeReservation=false;
   }
    console.log("BuisneddCardPopulate");
    console.log(businessData);
    var k =1;
      if(!businessData){
        console.log("Business Details empty");
        return;
      }

      //TODO
      var visibilityControl = document.getElementById("BusinessDetailsMain") as HTMLDivElement | null;
      visibilityControl!.style.visibility="visible";

      var visibilityControl2 = document.getElementById("businessDiv") as HTMLDivElement | null;
      visibilityControl2!.style.visibility="visible";

      if(businessData['name']){
      var heading = document.getElementById("businessHeading") as HTMLDivElement | null;
      this.businessName = businessData['name'];
      this.businessID=businessData['id'];
      heading!.innerHTML = businessData['name'];
      
      }
      if(businessData['location'] && businessData['location']['display_address']){
        var txt="<div class=\"flex-box\"><div class=\"flexHeadings\"><b>Address</b></div><div class=\"detailCardValues\">";
        for(var i=0;i<businessData['location']['display_address'].length-1;i++){
          txt+=businessData['location']['display_address'][i];
        }
        txt+=", "+businessData['location']['display_address'][i]+"</div></div>";
        heading = document.getElementById("Det"+k) as HTMLDivElement | null;
        heading!.innerHTML = txt;
        console.log(txt);
        k+=1;
      }
      if(businessData["categories"]){
        var tmp="";
        tmp+=businessData['categories'][0]['title'];
        for(var i=1;i<businessData['categories'].length;i++){
        tmp+="| "+businessData['categories'][i]['title'];
        }
        var txt="<div class=\"flex-box\"><div class=\"flexHeadings\"><b>Category</b></div><div class=\"detailCardValues\">";
        txt+=tmp+"</div></div>";
        heading = document.getElementById("Det"+k) as HTMLDivElement | null;
        heading!.innerHTML = txt;
        k+=1;

      
      }
      if(businessData["display_phone"]){
        
        var txt="<div class=\"flex-box\"><div class=\"flexHeadings\"><b>Phone</b></div><div class=\"detailCardValues\">";
        txt+=businessData["display_phone"]+"</div></div>";
        heading = document.getElementById("Det"+k) as HTMLDivElement | null;
        heading!.innerHTML = txt;
        k+=1;
      }
      if(businessData['price']){
        var txt="<div class=\"flex-box\"><div class=\"flexHeadings\"><b>Price range</b></div><div class=\"detailCardValues\">";
        txt+=businessData['price']+"</div></div>";
        heading = document.getElementById("Det"+k) as HTMLDivElement | null;
        heading!.innerHTML = txt;
        k+=1;
       
      }
      if(businessData['hours'] && businessData['hours'][0]['is_open_now']){
        
        var txt="<div class=\"flex-box\"><div class=\"flexHeadings\"><b>Status</b></div><div class=\"detailCardValues\">";
        if(businessData['hours'][0]['is_open_now']){
          txt+="Open"+"</div></div>";
        }
        else{
          txt+="Closed"+"</div></div>";
        }
        
        heading = document.getElementById("Det"+k) as HTMLDivElement | null;
        heading!.innerHTML = txt;
        k+=1;
        
      }
      if(businessData['url']){
        var txt ="<div class=\"flex-box\"><div class=\"flexHeadings\"><b>Visit yelp for more</b></div><div class=\"detailCardValues\"><a target=\"_blank\" href="+businessData['url']+">Business Link</div></div>"    
        heading = document.getElementById("Det"+k) as HTMLDivElement | null;
        heading!.innerHTML = txt;
        k++;
      }      
       if(businessData["name"] && businessData["url"]){
        this.twitterurl="https://twitter.com/intent/tweet?text=Check "+businessData["name"]+" on Yelp.&url="+businessData["url"];
        this.fburl = "https://www.facebook.com/sharer/sharer.php?u="+businessData['url'];
        var el = document.getElementById("tweets") as HTMLAnchorElement | null;
        el?.setAttribute("href",this.twitterurl);
      }
      for(var i=k;i<=7;i++){
        heading = document.getElementById("Det"+k) as HTMLDivElement | null;
        heading!.innerHTML = "";
      }
      console.log("Image links");
      console.log(businessData['photos']);

      this.prepareImageCarousel(businessData['photos']);
  
      this.renderMap(businessData);


  }
  ngOnInit(): void {
    this.__reservationFormService.newReserveEmitter.subscribe((data:any)=>{
      this.businessCardPopulate(this.businessDetailsViewData);

    })
    this.__businessTableDetailsViewService.businessDetailsEmitteer.subscribe((businessData:any)=>{
      this.businessCardPopulate(businessData);
    })

    this.__businessTableDetailsViewService.businessreviewEmitteer.subscribe((businessReviewData:any)=>{
      this.businessReviewPopulate(businessReviewData);
    })

    this.__businessTableDetailsViewService.displayBusinessDetailsEmitter.subscribe((displayInstruct:boolean)=>{
      this.BusinessDetailsDisplay = displayInstruct;
    })

    this.__formBusinessTableService.formSubmitStateEmitter.subscribe((businessTableView:boolean)=>{
      this.BusinessDetailsDisplay = !businessTableView;
    })

    this.__formBusinessTableService.clearViewBeforeBookingEmitter.subscribe((businessDetailView:boolean)=>{
      this.BusinessDetailsDisplay = businessDetailView;
    })
  }

}
