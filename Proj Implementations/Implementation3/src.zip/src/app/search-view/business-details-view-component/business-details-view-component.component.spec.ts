import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessDetailsViewComponentComponent } from './business-details-view-component.component';

describe('BusinessDetailsViewComponentComponent', () => {
  let component: BusinessDetailsViewComponentComponent;
  let fixture: ComponentFixture<BusinessDetailsViewComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BusinessDetailsViewComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BusinessDetailsViewComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
