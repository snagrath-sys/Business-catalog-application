import { Component, NgModule, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import { FormBusinessTableServiceService } from './form-business-table-service.service';

@Component({
  selector: 'app-search-view',
  template: `
      <app-form-component></app-form-component>
      <app-business-table-view-component></app-business-table-view-component>
      <app-business-details-view-component></app-business-details-view-component>
  `,
  styles: [
  ],
  providers: [FormBusinessTableServiceService]
})
export class SearchViewComponent implements OnInit {
  constructor(private __formBusinessTableService: FormBusinessTableServiceService) {}
  ngOnInit(){
  }

  onSubmit(){
  }

}