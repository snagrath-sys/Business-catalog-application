import { TestBed } from '@angular/core/testing';

import { FormBusinessTableServiceService } from './form-business-table-service.service';

describe('FormBusinessTableServiceService', () => {
  let service: FormBusinessTableServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FormBusinessTableServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
