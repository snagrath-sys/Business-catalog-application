import { TestBed } from '@angular/core/testing';

import { BusinessTableDetailsViewServiceService } from './business-table-details-view-service.service';

describe('BusinessTableDetailsViewServiceService', () => {
  let service: BusinessTableDetailsViewServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BusinessTableDetailsViewServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
