import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { EventEmitter } from '@angular/core';
import { BusinessTableViewComponentComponent } from './business-table-view-component/business-table-view-component.component';
/*Responsibilities of this service are:
1. Bind to keyword data and get autocomplete suggestions for keyword from Yelp servers (via our back End).
2. Keeping track of Location autofill checkbox, if checked get latitude longitude information using ipinfo API. 
3. Store this latitude longitude data in an instance of the formObject.
4. Upon submission of form, update the formObject with all latest values.
5. Get Business listing using this formObject from Yelp servers (via the back End).
6. Make the Business table view visible. Maintain a listing of the business details object returned. 
This will be used to generate table dynamically.
7. Maintains visibility state variables for business-table and business-details html tags.
8. Upon 'Clear', make both business table and business details not visible. Also revert state of formData object to original state.
*/
@Injectable({
  providedIn: 'root'
})
export class FormBusinessTableServiceService {
  businessDetailsVisibility:any=false;
  businessTableState:Array<any>;
  formDataEmitter:Subject<Object[]> = new Subject<Object[]>();
  formSubmitStateEmitter:Subject<boolean> = new Subject<boolean>();
  clearViewBeforeBookingEmitter:Subject<boolean> = new Subject<boolean>();
  // formSubmitState(businessTableState:boolean){
  //   this.formSubmitStateEmitter.next(businessTableState);
  // }
  jsonToJsObjectArr(resp:any){
    this.businessTableState=[];
    for(var i=0;i<Object.keys(resp).length; i++){
        this.businessTableState.push(resp[i]);
    }

  }
  clearSearchViewBeforeBooking(){
    
    //Clear Form, Make businessTable and Business Details invisible
    this.clearViewBeforeBookingEmitter.next(false);
    console.log("All cleared from service");

  }
  submitFormToServer(formDJson:any){
    
    var url = '/yelpBusinessDetails?'+"term="+formDJson["key"]+"&location="+formDJson["loc"]+"&categories="+formDJson["categ"]+"&radius="+formDJson["dis"]+"&autolocation="+formDJson["autoL"];
    
    var data;
    var error;
    var errorMessage:any;
    var response:any;
    console.log("SN submit Form to server service");
    this.http.get<any>(url).subscribe({
      next: data =>{
        // response = data.total;
        response = data;
        console.log("SN Business results sent from server");
        console.log(response);
        this.jsonToJsObjectArr(response);
        console.log("Final state of table");
        console.log(this.businessTableState);
        
        this.formDataEmitter.next(this.businessTableState);
        console.log("Form service after data update , before state change");
        this.formSubmitStateEmitter.next(true);
        console.log("Finsihed that hook");
        // this.formSubmitState(true);

        
      },
      error: error => {
            errorMessage = error.message;
            console.error('SN There was an error!', error);
           
        }
    })
   
  }

  
  constructor(private http:HttpClient) { this.businessTableState=[];}
}
