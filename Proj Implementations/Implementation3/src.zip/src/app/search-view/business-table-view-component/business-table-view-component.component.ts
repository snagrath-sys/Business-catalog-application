import { Component, OnInit , ViewChild} from '@angular/core';
import { FormBusinessTableServiceService } from '../form-business-table-service.service';
import { MatTableModule } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { BusinessTableDetailsViewServiceService } from '../business-table-details-view-service.service';
@Component({
  selector: 'app-business-table-view-component',
  templateUrl: './business-table-view-component.component.html',
  styleUrls: ['./business-table-view-component.component.css']
})

export class BusinessTableViewComponentComponent implements OnInit {
   @ViewChild(MatSort) sort: MatSort;
  businessTableDisplay=false;
  dynamicFormData:any=[{"id":2,"image":111,"business_name":'abc',"rating":3.4, "distance":9.00974361143623},{"id":3,"image":111,"business_name":'abc',"rating":3.4,"distance":2.1393948045797897}];
  index:number= 0;
  columns =['id','image','business_name','rating','distance'];

  constructor(private __formBusinessTableServie: FormBusinessTableServiceService, private __businessTableDetailsView : BusinessTableDetailsViewServiceService) {}
businessDetailsSentForQuery(row:any){

  console.log("Row data sent : "+row.id+"."+row.business_name) ;
  this.businessTableDisplay = false;
  this.__businessTableDetailsView.displayingBusinessDetailsOnly();
  this.__businessTableDetailsView.getDetailsonBusiness(row);
}

  ngOnInit(): void {
    this.__formBusinessTableServie.formDataEmitter.subscribe((formData:any)=>{
      console.log("Form data in table module");
      console.log(formData);
      this.index=1;
      this.dynamicFormData = formData;
      console.log("Formdata");
      console.log(formData);
      this.dynamicFormData.sort = this.sort;
      console.log("data after JSonify");
      console.log(this.dynamicFormData);
      

    })
    this.__formBusinessTableServie.formSubmitStateEmitter.subscribe((businessTableView:any)=>{
      this.businessTableDisplay = businessTableView;
      console.log("BusinessTableDisplay"+this.businessTableDisplay);
      
      
    })

    this.__formBusinessTableServie.clearViewBeforeBookingEmitter.subscribe((businessTableView:boolean)=>{
      this.businessTableDisplay = businessTableView;  
    })

    this.__businessTableDetailsView.displayBusinessTableEmitter.subscribe((businesstableV:boolean)=>{
      this.businessTableDisplay = businesstableV;
    })

    
  }
}
