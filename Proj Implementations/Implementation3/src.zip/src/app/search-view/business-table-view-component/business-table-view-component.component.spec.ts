import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessTableViewComponentComponent } from './business-table-view-component.component';

describe('BusinessTableViewComponentComponent', () => {
  let component: BusinessTableViewComponentComponent;
  let fixture: ComponentFixture<BusinessTableViewComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BusinessTableViewComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BusinessTableViewComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
