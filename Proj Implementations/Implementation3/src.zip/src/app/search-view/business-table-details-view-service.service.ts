import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
/*Responsibilities of this service are:
   1.Maintain copy of business details table values including business IDs.
   2. Upon click, identify the business detail entry. Using this get details from Yelp servers(via Back End).
   3. Once this information is ready, provide this info to the business details view section.
   4. Make business details view section visible.
   5. Scroll down to this section.
   6. Upon click on back button, scroll up to form view.
   7. Maintain window view position state for Form.
*/
@Injectable({
  providedIn: 'root'
})
export class BusinessTableDetailsViewServiceService {
  businessDetailsEmitteer:Subject<Object[]> = new Subject<Object[]>();
  businessreviewEmitteer:Subject<Object[]> = new Subject<Object[]>();
  displayBusinessDetailsEmitter:Subject<boolean> = new Subject<boolean>();
  displayBusinessTableEmitter:Subject<boolean> = new Subject<boolean>();
displayBusinessTableOnly(){
  this.displayBusinessTableEmitter.next(true); 

}
displayingBusinessDetailsOnly(){
  this.displayBusinessDetailsEmitter.next(true);
}
getBusinessreviews(row:any){
    var url = '/yelpReviewCard?'+"key="+row.id;
    var response, data, errMsg;
    console.log("review query "+url);
    this.http.get<any>(url).subscribe({
      next: data =>{
        response = data;
        console.log("Review response: "+response);
        this.businessreviewEmitteer.next(response);
      },
      error: error => {
        errMsg = error.message;
        console.error("SN There has been an error in review retrieval", error);
      }
    })

}
getDetailsonBusiness(row:any){
    this.getBusinessreviews(row);
    var url = '/yelpBusinessCard?'+"key="+row.id;
    var response, data, errMsg;
    console.log("details query: "+url);
    this.http.get<any>(url).subscribe({
      next: data =>{
        response = data;
        console.log("Details query response: "+response);
        this.businessDetailsEmitteer.next(response);
      },
      error: error => {
        errMsg = error.message;
        console.error("SN There has been an error in details retrieval", error);
      }
    })


  }
  constructor(private http:HttpClient) { }
}
