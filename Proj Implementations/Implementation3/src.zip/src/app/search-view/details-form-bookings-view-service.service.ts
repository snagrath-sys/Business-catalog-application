import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
/*Responsibilities of this service are:
   1. Upon submit of reservation form, update entry to HTML storage.
   2. Upon cancellation, remove entry from HTML storage.
   3. Upon click on 'Bookings' navBar button, dynamically use the HTML storage values to populate the bookings-view
      using the service. 
*/
@Injectable({
  providedIn: 'root'
})
export class DetailsFormBookingsViewServiceService {
  
  constructor() { }
}
