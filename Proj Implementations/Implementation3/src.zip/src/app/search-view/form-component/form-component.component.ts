import { HttpClient } from '@angular/common/http';
import { HtmlParser } from '@angular/compiler';
import { Component, Inject, OnInit } from '@angular/core';
import {FormControl, NgForm} from '@angular/forms';
import { FormBusinessTableServiceService } from '../form-business-table-service.service';
import {debounceTime, tap, switchMap, finalize, distinctUntilChanged, filter} from 'rxjs/operators';
import { DOCUMENT } from '@angular/common';
import {ViewChild} from '@angular/core';
/*
   form-component
   1. The html in the component is responsible for static display of the main Yelp query form.
   2. Two way bind the entries in the form to a formData object defined in the class.
   3. onClick on keyword, bind the typed text to a string variable. Call a method in the helper service to get
      auto-complete suggestions.
   4. Display these autocomplete suggestions as drop down.
   5. Distance input defaults to 10, Category input defaults to 'Default'.
   6. Only allow submit when all values have been populated, else display tooltip.
   7. Upon auto-detect my location checked, remove value from Location input and grey it out.
   8. When check-box unchecked, ungrey the field.
   9. When auto-detect location checked, call method in helper service to get latitude and longitudes.
   10. Upon submit call method to submit formData.
   11. Upon clear, set all form values to default.
*/

@Component({
  selector: 'app-form-component',
  templateUrl: './form-component.component.html',
  styleUrls: ['./form-component.component.css']
})
 export class FormComponentComponent implements OnInit {

  @ViewChild('formDirective') private formDirective: NgForm;

  constructor(private __formBusinessService: FormBusinessTableServiceService){

  }


  keywordInput:any;
  distance:any=10;
  category:any= "Default";
  location:any;
  autoLocation:any=false;
  locationFieldDisabled:any=false;
  clearDisplay(){
    // this.__formBusinessService.clearBusinessTableDisplay();
    this.formDirective.resetForm();
    this.__formBusinessService.clearSearchViewBeforeBooking();
  }

  missingValuesInForm(){
    
  if(this.keywordInput == ""  || this.keywordInput == undefined|| 
  this.distance == "" || this.distance<0 || this.distance==undefined|| 
  (this.autoLocation == false
  && (this.location == "" || this.location==undefined) )){
    return true;
  }
  return false;
}
locationToggleEnableDisable(){
if(this.locationFieldDisabled == false){
  this.location=""; 
  this.locationFieldDisabled =true;
  return;
}
this.location="";  
this.locationFieldDisabled=false;
}

  populateJSONobj(){
    console.log("Populate JSON");
    
    if(this.distance == null){
      this.distance = 10;
      this.category = "Default";
    }
    console.log(this.distance);
    console.log(this.category);
    if(this.missingValuesInForm()){
      return false;
     }
     var formdata = {
      key: this.keywordInput,
      dis:this.distance,
      categ:this.category,
      loc:this.location,
      autoL:this.autoLocation
     };

    //  var formDJSON = JSON.stringify(formdata);
    //  this.__formBusinessService.clearBusinessTableDisplay();
    console.log("Submitting data");
     this.__formBusinessService.submitFormToServer(formdata);
    //  this.__formBusinessService.formSubmitState(true);
   return true;
  }

  ngOnInit(): void {
     this.__formBusinessService.clearViewBeforeBookingEmitter.subscribe((clearingInstruct:any)=>{
      // var clearer = document.getElementById("formId") as HTMLFormElement | null;
      // clearer?.reset();
      console.log("After reset oin forms"); 
      // this.distance = 10;
      // this.category = "Default";
      
    })
  }

};



