import { Component, OnInit } from '@angular/core';
import { ReservationFormServiceService } from '../reservation-form-service.service';
@Component({
  selector: 'app-booking-view',
  templateUrl: './booking-view.component.html',
  styleUrls: ['./booking-view.component.css']
})
export class BookingViewComponent implements OnInit {
  
  constructor(private _reserveModalService: ReservationFormServiceService) { }
  
  dynamicBookingData:any=[{"index":2,"name":'abc',"date":"xx","time":"xx","emailId":"xx","deletion":""}];
  
  index:number= 0;
  columns =['index','name', 'date', 'time', 'emailId', 'deletion'];
 
  len:any;

  deleteEntry(bname:any){
    window.localStorage.removeItem(bname);
    this.displayBooking();
    window.alert("Reservation Cancelled");
  }
  displayBooking(){
       this.len = window.localStorage.length;

       var i,keyii;
       var tmp:any=[];
       
      for(i = 0; i<this.len ;i++){
        var ent:any={};
        var val;

        keyii = window.localStorage.key(i);
        if(keyii!=null && window.localStorage.getItem(keyii)!=null){
          val = JSON.parse(String(window.localStorage.getItem(keyii)));
        }
        

        if(keyii && val!= undefined && val !=null){
          console.log("B "+val);
          ent = val;
          ent['index']=1;
          ent['deletion']='*';
          console.log(ent);
          console.log(tmp);
          tmp.push(ent);

        }  
      }
      this.dynamicBookingData = tmp;

  }
  ngOnInit(): void {
     this.displayBooking();

      
  }

}
