import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { KeysPipe } from './keys.pipe';

import { AppRoutingModule , routingComponents} from './app-routing.module';
import { AppComponent } from './app.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import {MatAutocompleteModule} from '@angular/material/autocomplete'
import {MatInputModule} from '@angular/material/input'
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { FormComponentComponent } from './search-view/form-component/form-component.component';
import { BusinessTableViewComponentComponent } from './search-view/business-table-view-component/business-table-view-component.component';
import { BusinessDetailsViewComponentComponent } from './search-view/business-details-view-component/business-details-view-component.component';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatSortModule} from '@angular/material/sort';
import {MatTableModule} from '@angular/material/table';
import {MatTabsModule} from '@angular/material/tabs';
import { GoogleMapsModule } from '@angular/google-maps';
import { ReservationModalComponent } from './reservation-modal/reservation-modal.component';
import * as $ from 'jquery';
import { BookingViewComponent } from './booking-view/booking-view.component';
@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    PageNotFoundComponent,
    FormComponentComponent,
    BusinessTableViewComponentComponent,
    BusinessDetailsViewComponentComponent,
    KeysPipe,
    ReservationModalComponent,
    BookingViewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ReactiveFormsModule, 
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    MatAutocompleteModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatProgressSpinnerModule,
    MatTabsModule,
    GoogleMapsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatInputModule 

  ],
  exports:[MatSortModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
