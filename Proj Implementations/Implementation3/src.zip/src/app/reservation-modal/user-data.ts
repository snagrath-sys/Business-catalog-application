//user-data.ts
export class UserData {
	constructor(
	public primaryAddress: string,
	public secondaryAddress: string
	){}
}