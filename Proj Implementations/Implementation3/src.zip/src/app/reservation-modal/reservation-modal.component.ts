import { Component, OnInit } from '@angular/core';
import {ReservationFormServiceService} from '../reservation-form-service.service'
import {FormGroup, FormControl, Validators} from '@angular/forms';
import { UserData } from './user-data';

@Component({
  selector: 'app-reservation-modal',
  templateUrl: './reservation-modal.component.html',
  styleUrls: ['./reservation-modal.component.css']
})
export class ReservationModalComponent implements OnInit {
 
 
  ngOnInit(): void {
 
  }
  infoToken:any;
  formReservationUp:any = false;
  
  //Set current date
   dateToday = new Date();
  dd:any = this.dateToday.getDate();
  mm:any = this.dateToday.getMonth()+1;
  yy:any = this.dateToday.getFullYear();
   stringTodatDate:any='2022-11-07';

    dataMissing(dataObj:any){
      if(dataObj.email==null || dataObj.email==''||
      dataObj.date==null || dataObj.date=='' || dataObj.timeHour == null||
      dataObj.timeHour=='' || dataObj.timeMins=='' || dataObj.timeMins==null){
        return true;
      }
      return false;
    }
    registerReservation(){
    console.log("Data handler");
    console.log(this.reservationDetails.value);
      if(this.dataMissing(this.reservationDetails.value)){
        return;
      }
      if(typeof(Storage)!=="undefined"){
        console.log("Local storage supported by brwoser");
      }
      else{
        console.log("Local Storage not supported");
        return;
      }
      window.alert("Reservation Created!");
      var dataPack:any={
        name:this.infoToken['bName'],
        date:this.reservationDetails.value['date'],
        time:this.reservationDetails.value['timeHour']+" : "+this.reservationDetails.value['timeMins'],
        emailId:this.reservationDetails.value['email']
      };

      dataPack=JSON.stringify(dataPack);
      console.log("final json str to be stored");
      console.log(dataPack);

      window.localStorage.setItem(this.infoToken['bName'],dataPack);
      console.log("verifying storage");
      console.log(window.localStorage.getItem(this.infoToken['bName']));
      console.log(window.localStorage.length);
      var len = window.localStorage.length;
       var i,keyii;
      for(i = 0; i<len;i++){
        keyii = window.localStorage.key(i);
        console.log(window.localStorage.key(i));
        if(keyii){
          console.log(window.localStorage.getItem(keyii));
        }
        
      }
      this._reservationFormService.newReservationUpdate(dataPack);
    }

    clearModal(){
    this.reservationDetails.reset();

    }
    reservationDetails = new FormGroup({
    email: new FormControl(''),
    date: new FormControl(''),
    timeHour: new FormControl(''),
    timeMins: new FormControl('')
  });

   constructor(private _reservationFormService: ReservationFormServiceService){
    this._reservationFormService.reservationInfoEmitter.subscribe((infoToken:any)=>{
      console.log(infoToken);
      this.infoToken = infoToken;
      this.formReservationUp=true;
      
        if(this.dd < 10) {
    this.dd = "0" + this.dd.toString();
  };

  if(this.mm < 10) {
    this.mm = "0" + this.mm.toString();
  };
  this.stringTodatDate = this.yy.toString()+'-'+ this.mm.toString()+'-'+this.dd.toString();
  document.getElementById("start")?.setAttribute("min",this.stringTodatDate);
     
    // generateOptions()
      
    })


   
  }

}


// userModel = new UserData('','')


  // firstEmail = new FormControl("", [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]);